package com.bikerentalsystem.util;

import com.bikerentalsystem.models.Bike;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BikeDAO {
    private Connection connection;

    public BikeDAO() {
        try {
            connection = DatabaseConnection.getConnection();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Bike> getAllBikes() {
        List<Bike> bikeList = new ArrayList<>();
        String query = "SELECT * FROM bicycles";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Bike bike = new Bike();
                bike.setId(resultSet.getInt("id"));
                bike.setModel(resultSet.getString("model"));
                bike.setType(resultSet.getString("type"));
                bike.setAvailability(resultSet.getInt("availability"));
                bike.setPricePerHour(resultSet.getDouble("price_per_hour"));
                bikeList.add(bike);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bikeList;
    }

    public List<Bike> getAvailableBikes() {
        List<Bike> bikeList = new ArrayList<>();
        String query = "SELECT * FROM bicycles WHERE availability = 1";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                Bike bike = new Bike();
                bike.setId(resultSet.getInt("id"));
                bike.setModel(resultSet.getString("model"));
                bike.setType(resultSet.getString("type"));
                bike.setAvailability(resultSet.getInt("availability"));
                bike.setPricePerHour(resultSet.getDouble("price_per_hour"));
                bikeList.add(bike);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bikeList;
    }

    public void addBike(Bike bike) {
        String query = "INSERT INTO bicycles (model, type, availability, price_per_hour) VALUES (?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, bike.getModel());
            preparedStatement.setString(2, bike.getType());
            preparedStatement.setInt(3, bike.getAvailability());
            preparedStatement.setDouble(4, bike.getPricePerHour());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateBike(Bike bike) {
        String query = "UPDATE bicycles SET model = ?, type = ?, availability = ?, price_per_hour = ? WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, bike.getModel());
            preparedStatement.setString(2, bike.getType());
            preparedStatement.setInt(3, bike.getAvailability());
            preparedStatement.setDouble(4, bike.getPricePerHour());
            preparedStatement.setInt(5, bike.getId());
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteBike(int id) {
        String query = "DELETE FROM bicycles WHERE id = ?";

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Bike getBikeById(int id) {
        String query = "SELECT * FROM bicycles WHERE id = ?";
        Bike bike = null;

        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                bike = new Bike();
                bike.setId(resultSet.getInt("id"));
                bike.setModel(resultSet.getString("model"));
                bike.setType(resultSet.getString("type"));
                bike.setAvailability(resultSet.getInt("availability"));
                bike.setPricePerHour(resultSet.getDouble("price_per_hour"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return bike;
    }
}