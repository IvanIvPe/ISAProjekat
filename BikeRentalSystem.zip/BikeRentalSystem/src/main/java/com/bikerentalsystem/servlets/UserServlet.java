package com.bikerentalsystem.servlets;

import com.bikerentalsystem.models.User;
import com.bikerentalsystem.util.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;

@WebServlet("/user")
public class UserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;
    private static final Logger logger = Logger.getLogger(UserServlet.class.getName());

    public UserServlet() {
        this.userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("new".equals(action) || "insert".equals(action)) {
            try {
                switch (action) {
                    case "new":
                        showNewForm(request, response);
                        break;
                    case "insert":
                        insertUser(request, response);
                        break;
                }
            } catch (SQLException ex) {
                logger.severe("SQL Exception in UserServlet (doGet): " + ex.getMessage());
                throw new ServletException(ex);
            }
            return;
        }

        HttpSession session = request.getSession(false);
        User user = (User) (session != null ? session.getAttribute("user") : null);

        if (user == null) {
            logger.warning("No user session found. Redirecting to login page.");
            response.sendRedirect(request.getContextPath() + "/pages/login.jsp");
            return;
        }

        try {
            switch (action) {
                case "delete":
                    deleteUser(request, response);
                    break;
                case "edit":
                    showEditForm(request, response);
                    break;
                case "update":
                    updateUser(request, response);
                    break;
                default:
                    listUsers(request, response);
                    break;
            }
        } catch (SQLException ex) {
            logger.severe("SQL Exception in UserServlet (doGet - action handling): " + ex.getMessage());
            throw new ServletException(ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void listUsers(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        List<User> listUsers = userDAO.getAllUsers();
        request.setAttribute("listUsers", listUsers);
        logger.info("Listing users: " + listUsers.size() + " users found.");
        request.getRequestDispatcher("/pages/userList.jsp").forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/pages/userForm.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String idParam = request.getParameter("id");

        if (idParam == null || idParam.isEmpty()) {
            logger.warning("No ID provided for editing.");
            response.sendRedirect("user?action=list&error=Invalid ID");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idParam);
        } catch (NumberFormatException e) {
            logger.warning("Invalid ID format: " + idParam);
            response.sendRedirect("user?action=list&error=Invalid ID");
            return;
        }

        User existingUser = userDAO.getUserById(id);
        if (existingUser == null) {
            logger.warning("User not found for ID: " + id);
            response.sendRedirect("user?action=list&error=User Not Found");
            return;
        }

        logger.info("Forwarding to updateUser.jsp with user: " + existingUser);
        request.setAttribute("user", existingUser);
        request.getRequestDispatcher("/pages/updateUser.jsp").forward(request, response);
    }

    private void insertUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        String role = "User";

        if (name == null || email == null || password == null) {
            logger.warning("Missing required fields for user insertion.");
            response.sendRedirect("user?action=new&error=Missing Required Fields");
            return;
        }

        User newUser = new User();
        newUser.setName(name);
        newUser.setEmail(email);
        newUser.setPassword(password);
        newUser.setRole(role);

        userDAO.addUser(newUser);
        logger.info("User inserted: " + newUser);
        response.sendRedirect(request.getContextPath() + "/pages/login.jsp");
    }

    private void updateUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String idParam = request.getParameter("id");

        if (idParam == null || idParam.isEmpty()) {
            logger.warning("Invalid ID for updating");
            response.sendRedirect("user?action=list&error=Invalid ID");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idParam);
        } catch (NumberFormatException e) {
            logger.warning("Invalid ID format for updating: " + idParam);
            response.sendRedirect("user?action=list&error=Invalid ID");
            return;
        }

        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String role = request.getParameter("role");

        if (name == null || email == null || password == null || role == null) {
            logger.warning("Missing required fields for user update.");
            response.sendRedirect("user?action=edit&id=" + id + "&error=Missing Required Fields");
            return;
        }

        User user = new User();
        user.setId(id);
        user.setName(name);
        user.setEmail(email);
        user.setPassword(password);
        user.setRole(role);

        userDAO.updateUser(user);
        logger.info("User updated: " + user);
        response.sendRedirect("user?action=list");
    }


    private void deleteUser(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String idParam = request.getParameter("id");

        if (idParam == null || idParam.isEmpty()) {
            logger.warning("Invalid ID for deletion");
            response.sendRedirect("user?action=list&error=Invalid ID");
            return;
        }

        int id;
        try {
            id = Integer.parseInt(idParam);
        } catch (NumberFormatException e) {
            logger.warning("Invalid ID format for deletion: " + idParam);
            response.sendRedirect("user?action=list&error=Invalid ID");
            return;
        }

        userDAO.deleteUser(id);
        logger.info("User deleted with ID: " + id);
        response.sendRedirect("user?action=list");
    }
}