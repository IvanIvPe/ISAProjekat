package com.bikerentalsystem.servlets;

import com.bikerentalsystem.models.User;
import com.bikerentalsystem.util.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserDAO userDAO;

    public LoginServlet() {
        this.userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Ako korisnik vec ima sesiju, redirektuje ga na odgovarajucu stranicu
        HttpSession session = request.getSession(false);
        User user = (User) (session != null ? session.getAttribute("user") : null);

        if (user != null) {
            redirectUserBasedOnRole(user, request, response);
        } else {
            response.sendRedirect("pages/login.jsp");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        User user = userDAO.getUserByEmail(email);

        // Provera da li je korisnik pronadjen i da li se lozinka podudara
        if (user != null && user.getPassword().equals(password)) {
            // Kreiranje sesije i postavljanje korisnika u sesiju
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            redirectUserBasedOnRole(user, request, response);
        } else {
            request.setAttribute("errorMessage", "Invalid email or password");
            request.getRequestDispatcher("pages/login.jsp").forward(request, response);
        }
    }

    private void redirectUserBasedOnRole(User user, HttpServletRequest request, HttpServletResponse response) throws IOException {
        switch (user.getRole()) {
            case "Admin":
                response.sendRedirect(request.getContextPath() + "/pages/adminDashboard.jsp");
                break;
            case "User":
                response.sendRedirect(request.getContextPath() + "/pages/userDashboard.jsp");
                break;
            default:
                response.sendRedirect(request.getContextPath() + "/pages/login.jsp");
                break;
        }
    }
}