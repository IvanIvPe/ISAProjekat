package com.bikerentalsystem.servlets;

import com.bikerentalsystem.models.Bike;
import com.bikerentalsystem.models.Rental;
import com.bikerentalsystem.models.User;
import com.bikerentalsystem.util.BikeDAO;
import com.bikerentalsystem.util.RentalDAO;
import com.bikerentalsystem.util.UserDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class RentalServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private RentalDAO rentalDAO;
    private BikeDAO bikeDAO;

    public RentalServlet() {
        this.rentalDAO = new RentalDAO();
        this.bikeDAO = new BikeDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        String action = request.getParameter("action");

        try {
            switch (action) {
                case "new":
                    if (user != null && ("Admin".equals(user.getRole()) || "User".equals(user.getRole()))) {
                        showNewForm(request, response);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/pages/unauthorized.jsp");
                    }
                    break;
                case "insert":
                    if (user != null && ("Admin".equals(user.getRole()) || "User".equals(user.getRole()))) {
                        insertRental(request, response);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/pages/unauthorized.jsp");
                    }
                    break;
                case "delete":
                    if (user != null && "Admin".equals(user.getRole())) {
                        deleteRental(request, response);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/pages/unauthorized.jsp");
                    }
                    break;
                case "edit":
                    if (user != null && "Admin".equals(user.getRole())) {
                        showEditForm(request, response);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/pages/unauthorized.jsp");
                    }
                    break;
                case "update":
                    if (user != null && "Admin".equals(user.getRole())) {
                        updateRental(request, response);
                    } else {
                        response.sendRedirect(request.getContextPath() + "/pages/unauthorized.jsp");
                    }
                    break;
                default:
                    if (user != null && "User".equals(user.getRole())) {
                        listUserRentals(request, response, user);
                    } else {
                        listRentals(request, response);
                    }
                    break;
            }
        } catch (SQLException ex) {
            throw new ServletException(ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void listRentals(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        List<Rental> listRentals = rentalDAO.getAllRentals();
        request.setAttribute("listRentals", listRentals);
        request.getRequestDispatcher("/pages/rentalList.jsp").forward(request, response);
    }

    private void listUserRentals(HttpServletRequest request, HttpServletResponse response, User user)
            throws SQLException, ServletException, IOException {
        List<Rental> listRentals = rentalDAO.getRentalsByUserId(user.getId());
        request.setAttribute("listRentals", listRentals);
        request.getRequestDispatcher("/pages/rentalList.jsp").forward(request, response);
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        List<Bike> availableBikes = bikeDAO.getAvailableBikes();
        request.setAttribute("availableBikes", availableBikes);
        request.getRequestDispatcher("/pages/rentalForm.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String idParam = request.getParameter("id");

        if (idParam == null || idParam.isEmpty()) {
            response.sendRedirect("user?action=list&error=Invalid ID");
            return;
        }

        try {
            int id = Integer.parseInt(idParam);
            UserDAO userDAO = new UserDAO();
            User existingUser = userDAO.getUserById(id);
            request.setAttribute("user", existingUser);
            request.getRequestDispatcher("/pages/userForm.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.sendRedirect("user?action=list&error=Invalid ID");
        }
    }


    private void insertRental(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int userId = Integer.parseInt(request.getParameter("user_id"));
        int bikeId = Integer.parseInt(request.getParameter("bicycle_id"));
        Date rentalStart = parseDate(request.getParameter("rental_start"));
        Date rentalEnd = parseDate(request.getParameter("rental_end"));

        Rental newRental = new Rental();
        newRental.setUserId(userId);
        newRental.setBicycleId(bikeId);
        newRental.setRentalStart(rentalStart);
        newRental.setRentalEnd(rentalEnd);

        rentalDAO.addRental(newRental);
        response.sendRedirect(request.getContextPath() + "/pages/thankYou.jsp");
    }

    private void updateRental(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        int userId = Integer.parseInt(request.getParameter("user_id"));
        int bikeId = Integer.parseInt(request.getParameter("bicycle_id"));
        Date rentalStart = parseDate(request.getParameter("rental_start"));
        Date rentalEnd = parseDate(request.getParameter("rental_end"));

        Rental rental = new Rental();
        rental.setId(id);
        rental.setUserId(userId);
        rental.setBicycleId(bikeId);
        rental.setRentalStart(rentalStart);
        rental.setRentalEnd(rentalEnd);

        rentalDAO.updateRental(rental);
        response.sendRedirect("RentalServlet?action=list");
    }

    private void deleteRental(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        rentalDAO.deleteRental(id);
        response.sendRedirect("RentalServlet?action=list");
    }

    private Date parseDate(String dateString) {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        try {
            return formatter.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
}