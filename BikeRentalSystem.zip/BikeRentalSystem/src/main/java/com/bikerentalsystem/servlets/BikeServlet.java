package com.bikerentalsystem.servlets;

import com.bikerentalsystem.models.Bike;
import com.bikerentalsystem.models.User;
import com.bikerentalsystem.util.BikeDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Logger;

public class BikeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private BikeDAO bikeDAO;
    private static final Logger logger = Logger.getLogger(BikeServlet.class.getName());

    public BikeServlet() {
        this.bikeDAO = new BikeDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        String action = request.getParameter("action");

        try {
            if (user == null) {
                logger.warning("Unauthorized access attempt to BikeServlet by an unauthenticated user.");
                response.sendRedirect(request.getContextPath() + "/pages/unauthorized.jsp");
                return;
            }

            switch (action) {
                case "new":
                case "insert":
                case "delete":
                case "edit":
                case "update":
                    if (!"Admin".equals(user.getRole())) {
                        logger.warning("Unauthorized access attempt to BikeServlet by user: " + user.getEmail());
                        response.sendRedirect(request.getContextPath() + "/pages/unauthorized.jsp");
                        return;
                    }
                    handleAdminActions(request, response, action);
                    break;

                default:
                    listBikes(request, response);
                    break;
            }
        } catch (SQLException ex) {
            logger.severe("SQL Exception in BikeServlet (doGet): " + ex.getMessage());
            throw new ServletException(ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    private void handleAdminActions(HttpServletRequest request, HttpServletResponse response, String action)
            throws SQLException, ServletException, IOException {
        switch (action) {
            case "new":
                showNewForm(request, response);
                break;
            case "insert":
                insertBike(request, response);
                break;
            case "delete":
                deleteBike(request, response);
                break;
            case "edit":
                showEditForm(request, response);
                break;
            case "update":
                updateBike(request, response);
                break;
        }
    }

    private void showNewForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/pages/addBike.jsp").forward(request, response);
    }

    private void insertBike(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        String model = request.getParameter("model");
        String type = request.getParameter("type");
        int availability = Integer.parseInt(request.getParameter("availability"));
        double pricePerHour = Double.parseDouble(request.getParameter("pricePerHour"));

        Bike newBike = new Bike(model, type, availability, pricePerHour);
        bikeDAO.addBike(newBike);
        response.sendRedirect("BikeServlet?action=list");
    }

    private void deleteBike(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        bikeDAO.deleteBike(id);
        response.sendRedirect("BikeServlet?action=list");
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        Bike existingBike = bikeDAO.getBikeById(id);
        request.setAttribute("bike", existingBike);
        request.getRequestDispatcher("/pages/editBike.jsp").forward(request, response);
    }

    private void updateBike(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        String model = request.getParameter("model");
        String type = request.getParameter("type");
        int availability = Integer.parseInt(request.getParameter("availability"));
        double pricePerHour = Double.parseDouble(request.getParameter("pricePerHour"));

        Bike bike = new Bike(id, model, type, availability, pricePerHour);
        bikeDAO.updateBike(bike);
        response.sendRedirect("BikeServlet?action=list");
    }

    private void listBikes(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        List<Bike> listBikes = bikeDAO.getAllBikes();
        request.setAttribute("listBikes", listBikes);
        request.getRequestDispatcher("/pages/bikeList.jsp").forward(request, response);
    }
}