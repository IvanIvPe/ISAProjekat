package com.bikerentalsystem.models;

public class Bike {
    private int id;
    private String model;
    private String type;
    private int availability;
    private double pricePerHour;

    public Bike() {}

    // Konstruktor za kreairanje nove bicikle (bez id)
    public Bike(String model, String type, int availability, double pricePerHour) {
        this.model = model;
        this.type = type;
        this.availability = availability;
        this.pricePerHour = pricePerHour;
    }

    // Konstruktor za postojacu biciklu (sa ID)
    public Bike(int id, String model, String type, int availability, double pricePerHour) {
        this.id = id;
        this.model = model;
        this.type = type;
        this.availability = availability;
        this.pricePerHour = pricePerHour;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getAvailability() {
        return availability;
    }

    public void setAvailability(int availability) {
        this.availability = availability;
    }

    public double getPricePerHour() {
        return pricePerHour;
    }

    public void setPricePerHour(double pricePerHour) {
        this.pricePerHour = pricePerHour;
    }
}